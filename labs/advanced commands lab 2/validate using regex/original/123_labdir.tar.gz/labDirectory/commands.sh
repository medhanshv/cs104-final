# Write your commands here
# run with 'bash commands.sh' 


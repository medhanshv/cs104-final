rm -rf testcases/ result.csv 
cp -R .original/testcases .original/result.csv .
#!/bin/bash

cd ..
rm -rf working_directory 2>/dev/null
tar -xvzf working_directory.tar.gz
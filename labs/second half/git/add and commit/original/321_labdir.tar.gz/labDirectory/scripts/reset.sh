#!/bin/bash

# Reset file contents
rm -rf ../working_directory/ 2> /dev/null
cp -R backup_directory/ ../working_directory/
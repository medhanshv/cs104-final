#include <vector>
#include <queue>

using namespace std;

vector<int> bfs(vector<vector<int>> &edges){

    // "edges" is a representation of the graph in the Adjacency List Representation

    int n=edges.size();

    vector<bool> visited(n,true);

    vector<int> order;

    for(int i=0;i<n;i++){

        if(visited[i]){

            continue;
        }

        queue<int> sto;

        sto.push(i);

        while(!sto.empty()){

            int root=sto.front();
            sto.pop();

            if(visited[root]){

                continue;
            }

            visited[root]=true;
            order.push_back(root);
            for(auto x:edges[root]){

                if(visited[x]){

                    continue;
                }

                sto.push(x);
            }
        }
    }

    return order;
}
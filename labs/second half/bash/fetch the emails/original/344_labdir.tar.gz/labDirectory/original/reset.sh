# DO NOT MODIFY THIS FILE.

rm -rf cseEmails.txt getEmails.sh sortedEmails.txt emails.txt input.txt testcases
cp -R original/labDirectory/ .

# DO NOT MODIFY THIS FILE.

rm -rf testcases true_output mapping.txt README submission.sh
cp -R original/ .

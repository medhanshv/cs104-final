message=""
message+="Hello. "
message+="Hello. "
message +="No change"
str="HI. "
message+=" Another sentence. "
message+="Sentence "
message+="More text "

for i in range(10):
	message+="Indented. "
	message+="Tabbed. "
    
message  +=  "Trailing space.  "
message+="Multiple. Sentences. "
if (message=="Hi "):
	pass
else:
	message+="Hi "
	
message+="NoPeriod"
str+="Hi"
message=""
message+="Ends with a period. "
message+="Extra space.  "

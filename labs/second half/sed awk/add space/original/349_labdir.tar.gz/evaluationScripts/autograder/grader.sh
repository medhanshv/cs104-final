sed -i 's/\r$//g' add_space.sed

python3 script.py
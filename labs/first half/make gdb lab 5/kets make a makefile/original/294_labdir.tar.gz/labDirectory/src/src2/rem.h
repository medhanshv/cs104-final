#ifndef REM_H
#define REM_H

#include <vector>

void rem_front(std::vector<int>& v);
void rem_back(std::vector<int>& v);

#endif
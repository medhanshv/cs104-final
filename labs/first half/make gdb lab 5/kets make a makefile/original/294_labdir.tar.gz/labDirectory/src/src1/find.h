#ifndef FIND_H
#define FIND_H

#include <vector>

int find(const std::vector<int>& v, int n);
int get(const std::vector<int>& v, int idx);
#endif
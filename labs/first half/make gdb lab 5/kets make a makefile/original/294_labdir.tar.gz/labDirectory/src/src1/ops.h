#ifndef OPS_H
#define OPS_H
#include <vector>

int sum(const std::vector<int>& v);
int product(const std::vector<int>& v);

#endif
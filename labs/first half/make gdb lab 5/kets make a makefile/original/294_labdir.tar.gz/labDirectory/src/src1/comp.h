#ifndef COMP_H
#define COMP_H

#include <vector>

int max(const std::vector<int>& v);
int min(const std::vector<int>& v);

#endif
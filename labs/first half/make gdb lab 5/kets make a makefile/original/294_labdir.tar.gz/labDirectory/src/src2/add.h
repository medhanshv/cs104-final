#ifndef ADD_H
#define ADD_H

#include <vector>

void add_front(std::vector<int>& v, int n);
void add_back(std::vector<int>& v, int n);

#endif
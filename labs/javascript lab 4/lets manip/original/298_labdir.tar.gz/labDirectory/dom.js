function makeChanges() {

}
// sin.h
#ifndef SIN_H
#define SIN_H

double my_sin(double angle);

#endif // SIN_H

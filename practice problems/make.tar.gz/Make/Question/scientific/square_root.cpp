// square_root.cpp
#include <cmath>
#include "square_root.h"

double my_square_root(double x) {
    return std::sqrt(x);
}

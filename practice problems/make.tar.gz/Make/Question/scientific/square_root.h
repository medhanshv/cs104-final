// square_root.h
#ifndef SQUARE_ROOT_H
#define SQUARE_ROOT_H

double my_square_root(double x);

#endif // SQUARE_ROOT_H

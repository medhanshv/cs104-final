// tan.cpp
#include <cmath>
#include "tan.h"

double my_tan(double angle) {
    return std::tan(angle);
}

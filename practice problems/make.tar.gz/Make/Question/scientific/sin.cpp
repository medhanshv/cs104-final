// sin.cpp
#include <cmath>
#include "sin.h"

double my_sin(double angle) {
    return std::sin(angle);
}

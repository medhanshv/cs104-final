// cos.h
#ifndef COS_H
#define COS_H

double my_cos(double angle);

#endif // COS_H

// cos.cpp
#include <cmath>
#include "cos.h"

double my_cos(double angle) {
    return std::cos(angle);
}

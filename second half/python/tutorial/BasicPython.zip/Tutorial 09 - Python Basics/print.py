# Printing multiple objects
name = "Alice"
age = 30
height = 5.8
print("Name:", name, "Age:", age, "Height:", height)

# Demo using sep and end with multiple objects
print("One", "Two", "Three", sep=", ", end="!\n")
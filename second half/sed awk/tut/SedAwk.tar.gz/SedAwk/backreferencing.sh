echo "I am Sherlock Holmes" | sed 's/I am \([A-Za-z]*\) \([A-Za-z]*\)/\1 \2 is my name!/'

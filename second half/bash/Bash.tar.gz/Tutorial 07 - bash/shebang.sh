#! /usr/bin/bash
#shebang tells the shell how to interpret this script

echo "You are in a bash script"
#This prints where the bash shell executable is located
which bash  
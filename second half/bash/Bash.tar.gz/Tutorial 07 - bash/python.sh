#!/usr/bin/python

print("Hello")